<?php $__env->startSection('title', 'Tabel Sekolah'); ?>
<?php $__env->startSection('head'); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <!--tab SMP, SMA-->
    <div class="container">
        <div class="row">
            <div class="col s12">
                <ul class="tabs">
                    <li class="tab col m3 s12"><a id="tab_fn" class="teal-text" href="#smp">SMP</a></li>
                    <li class="tab col m3 s12"><a id="tab_fl" class="teal-text" href="#sma">SMA</a></li>
                    <div class="indicator teal" style="z-index:1"></div>
                </ul>
            </div>
        </div>
    </div>
    <!--^^^^^^^^^^^^^^^^^^^^^^^^^-->
    <div class="section white" id="smp" >
        <div class="container">
            <div class="row">
                <?php if(count($smp)): ?>
                    <div class="row">
                        <div class="col s12 m12 l12">
                            <?php /*<form id="form_fauna" action="<?php echo e(route('delete.all.cl')); ?>" method="post" name="delete_form">*/ ?>
                            <?php /*<a id="btn_del" data-position="bottom" data-delay="50" data-tooltip="delete this" class="waves-effect waves-light btn orange left tooltipped">Delete All</a>*/ ?>
                            <?php /*<input type="hidden" name="lbluid" value="<?php echo e($user->id); ?>">*/ ?>
                            <?php /*<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">*/ ?>
                            <?php /*</form>*/ ?>
                            <a href="<?php echo e(route('maps.all',['jenjang'=>'smp'])); ?>" class="waves-effect waves-light btn blue right">lihat Peta</a>
                        </div>
                    </div>
                <?php endif; ?>
                <table class="highlight">
                    <thead>
                    <tr>
                        <th data-field="id">NPSN</th>
                        <th data-field="nama">Nama Sekolah</th>
                        <th data-field="alamat">Alamat</th>
                        <th data-field="jenjang">Jenjang</th>
                        <th data-field="kecamatan">Kecamatan</th>
                    </tr>
                    </thead>
                    <?php $__empty_1 = true; foreach($smp as $dataSM): $__empty_1 = false; ?>
                        <tbody>
                        <tr>
                            <td><?php echo e($dataSM->npsn); ?></td>
                            <td><?php echo e($dataSM->nama); ?></td>
                            <td><?php echo e($dataSM->alamat); ?></td>
                            <td><?php echo e($dataSM->jenjang); ?></td>
                            <td><?php echo e($dataSM->kecamatan->nama); ?></td>
                            <td><a href="<?php echo e(route('map.sekolah',['npsn'=>$dataSM->npsn])); ?>" class="waves-effect waves-light btn green black-text">peta</a></td>
                        </tr>
                        <?php /*<?php if(\Auth::check()): ?>*/ ?>
                        <?php /*<a href="<?php echo e(route('edit.school',['npsn'=>$dataSM->npsn])); ?>" class="black-text">*/ ?>
                        <?php /*<?php else: ?>*/ ?>
                        <?php /*<a href="<?php echo e(route('map.sekolah',['npsn'=>$dataSM->npsn])); ?>" class="black-text">*/ ?>
                        <?php /*<?php endif; ?>*/ ?>
                        <?php /*<div class="col s6 m6 l4">*/ ?>
                        <?php /*<div id="c_user" class="card-panel z-depth-1 hoverable">*/ ?>
                        <?php /*<div id="cc_user">*/ ?>
                        <?php /*<div class="card-content">*/ ?>
                        <?php /*<h5><?php echo e($dataSM->nama); ?></h5>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<div class="card-content">*/ ?>
                        <?php /*<span><?php echo e($dataSM->alamat); ?></span>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<?php if(\Auth::check()): ?>*/ ?>
                        <?php /*<div id="del_user">*/ ?>
                        <?php /*<form id="form_user" action="<?php echo e(route('deleteFg')); ?>" method="post" name="register_form">*/ ?>
                        <?php /*<form id="form_user" action="<?php echo e(route('school.delete')); ?>" method="post" name="register_form">*/ ?>
                        <?php /*<div class="card-content">*/ ?>
                        <?php /*<span><?php echo e($dataSM->npsn); ?><a id="sec_con" class="secondary-content"><i class="material-icons" onclick="peta(<?php echo e($dataSM->npsn); ?>)">pin_drop</i><i class="material-icons" onclick="apus(this)">deletes</i></a></span>*/ ?>
                        <?php /*<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">*/ ?>
                        <?php /*<input type="hidden" name="lblsc" value="<?php echo e($dataSM->npsn); ?>">*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*</form>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<?php else: ?>*/ ?>
                        <?php /*<div id="del_user">*/ ?>
                        <?php /*<form id="form_user" action="<?php echo e(route('deleteFg')); ?>" method="post" name="register_form">*/ ?>
                        <?php /*<div class="card-content">*/ ?>
                        <?php /*<span><?php echo e($dataSM->npsn); ?></span>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<?php endif; ?>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*</a>*/ ?>
                        <?php endforeach; if ($__empty_1): ?>
                            <center><h3 class="red-text">No School</h3></center>
                        <?php endif; ?>
                        </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="section white" id="sma" >
        <div class="container">
            <div class="row">
                <?php if(count($sma)): ?>
                    <div class="row">
                        <div class="col s6 m12 l12">
                            <?php /*<form id="form_fauna" action="<?php echo e(route('delete.all.cl')); ?>" method="post" name="delete_form">*/ ?>
                            <?php /*<a id="btn_del" data-position="bottom" data-delay="50" data-tooltip="delete this" class="waves-effect waves-light btn orange left tooltipped">Delete All</a>*/ ?>
                            <?php /*<input type="hidden" name="lbluid" value="<?php echo e($user->id); ?>">*/ ?>
                            <?php /*<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">*/ ?>
                            <?php /*</form>*/ ?>
                            <a href="<?php echo e(route('maps.all',['jenjang'=>'sma'])); ?>" class="waves-effect waves-light btn blue right">lihat Peta</a>
                        </div>
                    </div>
                <?php endif; ?>
                <table class="highlight">
                    <thead>
                    <tr>
                        <th data-field="id">NPSN</th>
                        <th data-field="nama">Nama Sekolah</th>
                        <th data-field="alamat">Alamat</th>
                        <th data-field="jenjang">Jenjang</th>
                        <th data-field="kecamatan">Kecamatan</th>
                    </tr>
                    </thead>
                    <?php $__empty_1 = true; foreach($sma as $dataSM): $__empty_1 = false; ?>
                        <tbody>
                        <tr>
                            <td><?php echo e($dataSM->npsn); ?></td>
                            <td><?php echo e($dataSM->nama); ?></td>
                            <td><?php echo e($dataSM->alamat); ?></td>
                            <td><?php echo e($dataSM->jenjang); ?></td>
                            <td><?php echo e($dataSM->kecamatan->nama); ?></td>
                            <td><a href="<?php echo e(route('edit.school',['npsn'=>$dataSM->npsn])); ?>" class="waves-effect waves-light btn green black-text">ubah</a></td>
                        </tr>
                        <?php /*<a href="" class="black-text">*/ ?>
                        <?php /*<?php if(\Auth::check()): ?>*/ ?>
                        <?php /*<a href="<?php echo e(route('edit.school',['npsn'=>$dataSM->npsn])); ?>" class="black-text">*/ ?>
                        <?php /*<?php else: ?>*/ ?>
                        <?php /*<a href="<?php echo e(route('map.sekolah',['npsn'=>$dataSM->npsn])); ?>" class="black-text">*/ ?>
                        <?php /*<?php endif; ?>*/ ?>
                        <?php /*<div class="col s6 m6 l4">*/ ?>
                        <?php /*<div id="c_user" class="card-panel z-depth-1 hoverable">*/ ?>
                        <?php /*<div id="cc_user">*/ ?>
                        <?php /*<div class="card-content">*/ ?>
                        <?php /*<h5><?php echo e($dataSM->nama); ?></h5>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<div class="card-content">*/ ?>
                        <?php /*<span><?php echo e($dataSM->alamat); ?></span>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<?php if(\Auth::check()): ?>*/ ?>
                        <?php /*<div id="del_user">*/ ?>
                        <?php /*<form id="form_user" action="<?php echo e(route('deleteFg')); ?>" method="post" name="register_form">*/ ?>
                        <?php /*<form id="form_user" action="<?php echo e(route('school.delete')); ?>" method="post" name="register_form">*/ ?>

                        <?php /*<div class="card-content">*/ ?>
                        <?php /*<span><?php echo e($dataSM->npsn); ?><a id="sec_cona" class="secondary-content"><i class="material-icons" onclick="peta(<?php echo e($dataSM->npsn); ?>)">pin_drop</i><i class="material-icons" onclick="apus(this)">deletes</i></a></span>*/ ?>
                        <?php /*<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">*/ ?>
                        <?php /*<input type="hidden" name="lblsc" value="<?php echo e($dataSM->npsn); ?>">*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*</form>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<?php else: ?>*/ ?>
                        <?php /*<div id="del_user">*/ ?>
                        <?php /*<form id="form_user" action="<?php echo e(route('deleteFg')); ?>" method="post" name="register_form">*/ ?>
                        <?php /*<div class="card-content">*/ ?>
                        <?php /*<span><?php echo e($dataSM->npsn); ?></span>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<?php endif; ?>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*</a>*/ ?>
                        <?php endforeach; if ($__empty_1): ?>
                            <center><h3 class="red-text">No School</h3></center>
                        <?php endif; ?>
                        </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="section">
        <div class="container center">
            <?php echo (new App\Pagination($smp))->render(); ?>

        </div>
    </div>
    <script>
        function peta(npsn) {
            window.location = "/bismillah/sekolah/"+npsn+"/lokasi";
        }
        function apus(e) {
            if (confirm('Hapus Sekolah?')) {
                //$(this).prev('span.text').remove();
                $(e).closest('form').submit();
            }
        }
        $(document).ready(function() {
            $('#sec_con').hover(function () {
                        $(this).css('cursor','pointer');
                        $(this).css('cursor','hand');
                    },function () {
                        $(this).css('cursor','auto');
                    }
            )
            $('#sec_cona').hover(function () {
                        $(this).css('cursor','pointer');
                        $(this).css('cursor','hand');
                    },function () {
                        $(this).css('cursor','auto');
                    }
            )
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <footer style="background-color: #0D47A1" class="page-footer">
        <div class="container">
            <div class="row">
                <div class="col l6 s12">
                    <h5 class="white-text"><?php echo e(Lang::get('detail.about')); ?></h5>
                    <ul>
                        <li><a class="grey-text text-lighten-3" href="#!">Alamat Kantor</a></li>
                        <li><a class="grey-text text-lighten-3" href="#!">Indonesia</a></li>
                        <li><a class="grey-text text-lighten-3" href="#!">email@email.com</a></li>
                        <li><a class="grey-text text-lighten-3" href="#!">876543210</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <div class="container">
                © 2016 Copyright
                <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
        </div>
    </footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>