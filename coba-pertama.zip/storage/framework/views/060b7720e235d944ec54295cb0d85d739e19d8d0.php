<!--Header HTML code -->
<!DOCTYPE html>
  <html lang="en">
    <head>
    	<title><?php echo $__env->yieldContent('title'); ?></title>
        <style>
            body {
                display: flex;
                min-height: 100vh;
                flex-direction: column;
            }

            main {
                flex: 1 0 auto;
            }
        </style>
    	<?php echo $__env->make('template.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('head'); ?>
    </head>

    <body bgcolor="#0D47A1">
    <header>
        <?php echo $__env->make('template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </header>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->yieldContent('footer'); ?>
    </body>
  </html>


<!--Footer HTML code-->