<!--Header HTML code -->
<!DOCTYPE html>
  <html lang="en">
    <!--<base href="http://localhost/kh/"></base>-->
    <head>
    	<title><?php echo $__env->yieldContent('title'); ?></title>
    	<?php echo $__env->make('template.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('head'); ?>
    </head>

    <body bgcolor="#26A69A">
			<?php echo $__env->yieldContent('content'); ?>
    </body>
  </html>


<!--Footer HTML code-->