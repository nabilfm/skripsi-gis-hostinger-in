<?php /*<?php if(Session::has('success')): ?>*/ ?>
<?php /*<div class="container">*/ ?>
<?php /*<div class="row">*/ ?>
<?php /*<div class="input-field col s12 center">*/ ?>
<?php /*<p id="desc_web" class="center white-text"><?php echo e(Session::get('success')); ?>addaaaaa</p>*/ ?>
<?php /*</div>*/ ?>
<?php /*</div>*/ ?>
<?php /*</div>*/ ?>
<?php /*<?php else: ?>*/ ?>
<?php /*<div class="container">*/ ?>
<?php /*<div class="row">*/ ?>
<?php /*<div class="input-field col s12 center">*/ ?>
<?php /*<p id="desc_web" class="center white-text"><?php echo e(Session::get('success')); ?> ga ada</p>*/ ?>
<?php /*</div>*/ ?>
<?php /*</div>*/ ?>
<?php /*</div>*/ ?>
<?php /*<?php endif; ?>*/ ?>


<?php if(\Auth::check()): ?>
        <!--fixed button checklist-->
<div id="fab_sc" class="fixed-action-btn">
    <a  href="<?php echo e(route('create.school')); ?>" class="btn-floating btn-large red">
        <i class="large material-icons">add</i>
    </a>
</div>
<!--^^^^^^^^^^^^^^^^^^^^^^^^^-->
<?php endif; ?>

        <!--tab SMP, SMA-->
<div class="container">
    <div class="row">
        <div class="col s12">
            <ul class="tabs">
                <li class="tab col m3 s12"><a id="tab_fn" class="teal-text" href="#smp">SMP</a></li>
                <li class="tab col m3 s12"><a id="tab_fl" class="teal-text" href="#sma">SMA</a></li>
                <div class="indicator teal" style="z-index:1"></div>
            </ul>
        </div>
    </div>
</div>
<!--^^^^^^^^^^^^^^^^^^^^^^^^^-->
<div class="section white" id="smp" >
    <div class="container">
        <div class="row">
            <?php if(count($smp)): ?>
                <div class="row">
                    <div class="col s12 m12 l12">
                        <?php /*<form id="form_fauna" action="<?php echo e(route('delete.all.cl')); ?>" method="post" name="delete_form">*/ ?>
                        <?php /*<a id="btn_del" data-position="bottom" data-delay="50" data-tooltip="delete this" class="waves-effect waves-light btn orange left tooltipped">Delete All</a>*/ ?>
                        <?php /*<input type="hidden" name="lbluid" value="<?php echo e($user->id); ?>">*/ ?>
                        <?php /*<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">*/ ?>
                        <?php /*</form>*/ ?>
                        <a href="<?php echo e(route('maps.all',['jenjang'=>'smp'])); ?>" class="waves-effect waves-light btn blue right">lihat Peta</a>
                    </div>
                </div>
            <?php endif; ?>
                <table class="highlight">
                    <thead>
                    <tr>
                        <th data-field="id">NPSN</th>
                        <th data-field="nama">Nama Sekolah</th>
                        <th data-field="alamat">Alamat</th>
                        <th data-field="jenjang">Jenjang</th>
                        <th data-field="kecamatan">Kecamatan</th>
                    </tr>
                    </thead>
            <?php $__empty_1 = true; foreach($smp as $dataSM): $__empty_1 = false; ?>
                        <tbody>
                        <tr>
                            <td><?php echo e($dataSM->npsn); ?></td>
                            <td><?php echo e($dataSM->nama); ?></td>
                            <td><?php echo e($dataSM->alamat); ?></td>
                            <td><?php echo e($dataSM->jenjang); ?></td>
                            <td><?php echo e($dataSM->kecamatan->nama); ?></td>
                            <td><a href="<?php echo e(route('edit.school',['npsn'=>$dataSM->npsn])); ?>" class="waves-effect waves-light btn green black-text">ubah</a></td>
                        </tr>
                <?php /*<?php if(\Auth::check()): ?>*/ ?>
                    <?php /*<a href="<?php echo e(route('edit.school',['npsn'=>$dataSM->npsn])); ?>" class="black-text">*/ ?>
                        <?php /*<?php else: ?>*/ ?>
                            <?php /*<a href="<?php echo e(route('map.sekolah',['npsn'=>$dataSM->npsn])); ?>" class="black-text">*/ ?>
                                <?php /*<?php endif; ?>*/ ?>
                                <?php /*<div class="col s6 m6 l4">*/ ?>
                                    <?php /*<div id="c_user" class="card-panel z-depth-1 hoverable">*/ ?>
                                        <?php /*<div id="cc_user">*/ ?>
                                            <?php /*<div class="card-content">*/ ?>
                                                <?php /*<h5><?php echo e($dataSM->nama); ?></h5>*/ ?>
                                            <?php /*</div>*/ ?>
                                            <?php /*<div class="card-content">*/ ?>
                                                <?php /*<span><?php echo e($dataSM->alamat); ?></span>*/ ?>
                                            <?php /*</div>*/ ?>
                                        <?php /*</div>*/ ?>
                                        <?php /*<?php if(\Auth::check()): ?>*/ ?>
                                            <?php /*<div id="del_user">*/ ?>
                                                <?php /*<form id="form_user" action="<?php echo e(route('deleteFg')); ?>" method="post" name="register_form">*/ ?>
                                                <?php /*<form id="form_user" action="<?php echo e(route('school.delete')); ?>" method="post" name="register_form">*/ ?>
                                                    <?php /*<div class="card-content">*/ ?>
                                                        <?php /*<span><?php echo e($dataSM->npsn); ?><a id="sec_con" class="secondary-content"><i class="material-icons" onclick="peta(<?php echo e($dataSM->npsn); ?>)">pin_drop</i><i class="material-icons" onclick="apus(this)">deletes</i></a></span>*/ ?>
                                                        <?php /*<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">*/ ?>
                                                        <?php /*<input type="hidden" name="lblsc" value="<?php echo e($dataSM->npsn); ?>">*/ ?>
                                                    <?php /*</div>*/ ?>
                                                <?php /*</form>*/ ?>
                                            <?php /*</div>*/ ?>
                                        <?php /*<?php else: ?>*/ ?>
                                            <?php /*<div id="del_user">*/ ?>
                                                <?php /*<form id="form_user" action="<?php echo e(route('deleteFg')); ?>" method="post" name="register_form">*/ ?>
                                                <?php /*<div class="card-content">*/ ?>
                                                    <?php /*<span><?php echo e($dataSM->npsn); ?></span>*/ ?>
                                                <?php /*</div>*/ ?>
                                            <?php /*</div>*/ ?>
                                        <?php /*<?php endif; ?>*/ ?>
                                    <?php /*</div>*/ ?>
                                <?php /*</div>*/ ?>
                            <?php /*</a>*/ ?>
                            <?php endforeach; if ($__empty_1): ?>
                                <center><h3 class="red-text">No School</h3></center>
                    <?php endif; ?>
                        </tbody>
                </table>
        </div>
    </div>
</div>
<div class="section white" id="sma" >
    <div class="container">
        <div class="row">
            <?php if(count($sma)): ?>
                <div class="row">
                    <div class="col s6 m12 l12">
                        <?php /*<form id="form_fauna" action="<?php echo e(route('delete.all.cl')); ?>" method="post" name="delete_form">*/ ?>
                        <?php /*<a id="btn_del" data-position="bottom" data-delay="50" data-tooltip="delete this" class="waves-effect waves-light btn orange left tooltipped">Delete All</a>*/ ?>
                        <?php /*<input type="hidden" name="lbluid" value="<?php echo e($user->id); ?>">*/ ?>
                        <?php /*<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">*/ ?>
                        <?php /*</form>*/ ?>
                        <a href="<?php echo e(route('maps.all',['jenjang'=>'sma'])); ?>" class="waves-effect waves-light btn blue right">lihat Peta</a>
                    </div>
                </div>
            <?php endif; ?>
                <table class="highlight">
                    <thead>
                    <tr>
                        <th data-field="id">NPSN</th>
                        <th data-field="nama">Nama Sekolah</th>
                        <th data-field="alamat">Alamat</th>
                        <th data-field="jenjang">Jenjang</th>
                        <th data-field="kecamatan">Kecamatan</th>
                    </tr>
                    </thead>
            <?php $__empty_1 = true; foreach($sma as $dataSM): $__empty_1 = false; ?>
                        <tbody>
                        <tr>
                            <td><?php echo e($dataSM->npsn); ?></td>
                            <td><?php echo e($dataSM->nama); ?></td>
                            <td><?php echo e($dataSM->alamat); ?></td>
                            <td><?php echo e($dataSM->jenjang); ?></td>
                            <td><?php echo e($dataSM->kecamatan->nama); ?></td>
                            <td><a href="<?php echo e(route('edit.school',['npsn'=>$dataSM->npsn])); ?>" class="waves-effect waves-light btn green black-text">ubah</a></td>
                        </tr>
                <?php /*<a href="" class="black-text">*/ ?>
                <?php /*<?php if(\Auth::check()): ?>*/ ?>
                    <?php /*<a href="<?php echo e(route('edit.school',['npsn'=>$dataSM->npsn])); ?>" class="black-text">*/ ?>
                        <?php /*<?php else: ?>*/ ?>
                            <?php /*<a href="<?php echo e(route('map.sekolah',['npsn'=>$dataSM->npsn])); ?>" class="black-text">*/ ?>
                                <?php /*<?php endif; ?>*/ ?>
                                <?php /*<div class="col s6 m6 l4">*/ ?>
                                    <?php /*<div id="c_user" class="card-panel z-depth-1 hoverable">*/ ?>
                                        <?php /*<div id="cc_user">*/ ?>
                                            <?php /*<div class="card-content">*/ ?>
                                                <?php /*<h5><?php echo e($dataSM->nama); ?></h5>*/ ?>
                                            <?php /*</div>*/ ?>
                                            <?php /*<div class="card-content">*/ ?>
                                                <?php /*<span><?php echo e($dataSM->alamat); ?></span>*/ ?>
                                            <?php /*</div>*/ ?>
                                        <?php /*</div>*/ ?>
                                        <?php /*<?php if(\Auth::check()): ?>*/ ?>
                                            <?php /*<div id="del_user">*/ ?>
                                                <?php /*<form id="form_user" action="<?php echo e(route('deleteFg')); ?>" method="post" name="register_form">*/ ?>
                                                <?php /*<form id="form_user" action="<?php echo e(route('school.delete')); ?>" method="post" name="register_form">*/ ?>

                                                    <?php /*<div class="card-content">*/ ?>
                                                        <?php /*<span><?php echo e($dataSM->npsn); ?><a id="sec_cona" class="secondary-content"><i class="material-icons" onclick="peta(<?php echo e($dataSM->npsn); ?>)">pin_drop</i><i class="material-icons" onclick="apus(this)">deletes</i></a></span>*/ ?>
                                                        <?php /*<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">*/ ?>
                                                        <?php /*<input type="hidden" name="lblsc" value="<?php echo e($dataSM->npsn); ?>">*/ ?>
                                                    <?php /*</div>*/ ?>
                                                <?php /*</form>*/ ?>
                                            <?php /*</div>*/ ?>
                                        <?php /*<?php else: ?>*/ ?>
                                            <?php /*<div id="del_user">*/ ?>
                                                <?php /*<form id="form_user" action="<?php echo e(route('deleteFg')); ?>" method="post" name="register_form">*/ ?>
                                                <?php /*<div class="card-content">*/ ?>
                                                    <?php /*<span><?php echo e($dataSM->npsn); ?></span>*/ ?>
                                                <?php /*</div>*/ ?>
                                            <?php /*</div>*/ ?>
                                        <?php /*<?php endif; ?>*/ ?>
                                    <?php /*</div>*/ ?>
                                <?php /*</div>*/ ?>
                            <?php /*</a>*/ ?>
                            <?php endforeach; if ($__empty_1): ?>
                                <center><h3 class="red-text">No School</h3></center>
                    <?php endif; ?>
                    </tbody>
                </table>
        </div>
    </div>
</div>
<div class="section">
    <div class="container center">
        <?php echo (new App\Pagination($smp))->render(); ?>

    </div>
</div>
<script>
    function peta(npsn) {
        window.location = "/bismillah/sekolah/"+npsn+"/lokasi";
    }
    function apus(e) {
        if (confirm('Hapus Sekolah?')) {
            //$(this).prev('span.text').remove();
            $(e).closest('form').submit();
        }
    }
    $(document).ready(function() {
        $('#sec_con').hover(function () {
                    $(this).css('cursor','pointer');
                    $(this).css('cursor','hand');
                },function () {
                    $(this).css('cursor','auto');
                }
        )
        $('#sec_cona').hover(function () {
                    $(this).css('cursor','pointer');
                    $(this).css('cursor','hand');
                },function () {
                    $(this).css('cursor','auto');
                }
        )
    });
</script>