<?php $__env->startSection('title', 'home page'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="input-field col s12 center">
                <p id="desc_web" class="center white-text">Description here...</p>
            </div>
        </div>
    </div>
    <!--fixed action button language-->
    <div id="fab_fn" class="fixed-action-btn click-to-toggle" style="bottom: 10px; right: 24px;">
        <!-- Dropdown Trigger -->
        <a class='dropdown-button btn orange'><?php echo e(Lang::get('detail.language.label')); ?></a>
        <ul class="collection">
            <li class="collection-item">
                <a href="<?php echo e(route('beranda',['lang'=>'id'])); ?>">
                    <img src="<?php echo e(url('smbr/img/flag_id.png')); ?>" class="circle" style="width: 30px;height: 30px;">
                    <br>
                    Indonesia
                </a>
            </li>
            <li class="collection-item">
                <a href="<?php echo e(route('beranda',['lang'=>'en'])); ?>">
                    <img src="<?php echo e(url('smbr/img/flag_en.png')); ?>" class="circle" style="width: 30px;height: 30px;">
                    <br>
                    English
                </a>
            </li>
        </ul>
    </div>
    <!--^^^^^^^^^^^^^^^^^^^^^^^^^-->
    <!--tab fieldguide, fauna, flora-->
    <div class="container">
        <div class="row">
            <div class="col s12">
                <ul class="tabs">
                    <li class="tab col m3 s12"><a id="tab_fn" class="teal-text" href="#fn">Fauna</a></li>
                    <li class="tab col m3 s12"><a id="tab_fl" class="teal-text" href="#fl">Flora</a></li>
                    <div class="indicator teal" style="z-index:1"></div>
                </ul>
            </div>
        </div>
    </div>
    <!--^^^^^^^^^^^^^^^^^^^^^^^^^-->
    <div class="section white" id="fn" >
        <div class="container">
            <div class="row">
                <?php $__empty_1 = true; foreach($dataFn as $dataFndb): $__empty_1 = false; ?>
                    <a href="<?php echo e(route('detail.fn',['label'=>$dataFndb->label,'lang'=>$lang])); ?>" class="black-text">
                        <div class="col s12 m6 l6">
                            <div id="c_fg" class="card small z-depth-1 hoverable">
                                <div class="card-image">
                                    <?php $__empty_2 = true; foreach($dataFndb->images->take(1) as $dataimg): $__empty_2 = false; ?>
                                        <center><img src="<?php echo e(url($dataimg->path.$dataimg->filename)); ?>" class="responsive-img"></center>
                                    <?php endforeach; if ($__empty_2): ?>
                                        <center><span>No Image</span></center>
                                    <?php endif; ?>
                                </div>
                                <div class="card-content">
                                    <h5><?php echo e($dataFndb->nameId); ?></h5>
                                    <div class="row">
                                        <div class="col s12">
                                            <span><?php echo e($dataFndb->nameEn); ?></span>
                                            <br>
                                            <span><i><?php echo e($dataFndb->nameLat); ?></i></span>
                                            <?php /*<p><a href="#">This is a link</a></p>*/ ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php endforeach; if ($__empty_1): ?>
                    <center><h3 class="red-text">No Fauna</h3></center>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="section white" id="fl" >
        <div class="container">
            <div class="row">
                <?php $__empty_1 = true; foreach($dataFl as $dataFldb): $__empty_1 = false; ?>
                    <a href="<?php echo e(route('detail.fl',['label'=>$dataFldb->label,'lang'=>$lang])); ?>" class="black-text">
                        <div class="col s12 m6 l6" >
                            <div id="c_fg" class="card small z-depth-1 hoverable">
                                <div class="card-image">
                                    <?php $__empty_2 = true; foreach($dataFldb->images->take(1) as $dataflimg): $__empty_2 = false; ?>
                                        <center><img src="<?php echo e(url($dataflimg->path.$dataflimg->filename)); ?>" class="responsive-img"></center>
                                    <?php endforeach; if ($__empty_2): ?>
                                        <center><span>No Image</span></center>
                                    <?php endif; ?>
                                </div>
                                <div class="card-content">
                                    <h5><?php echo e($dataFldb->nameId); ?></h5>
                                    <div class="row">
                                        <div class="col s12">
                                            <span><?php echo e($dataFldb->nameEn); ?></span>
                                            <br>
                                            <span><i><?php echo e($dataFldb->nameLat); ?></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php endforeach; if ($__empty_1): ?>
                    <center><h3 class="red-text">No Flora</center></h3>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="section">
        <div class="container center">
            <?php echo (new App\Pagination($dataFn))->render(); ?>

        </div>
    </div>
    <?php /*<script>*/ ?>
        <?php /*$(document).ready(function() {*/ ?>
            <?php /*$('div.hoverable').hover(*/ ?>
                    <?php /*function () {*/ ?>
                        <?php /*$(this).addClass('pink');*/ ?>
    <?php /*//	                  $(this).css('cursor', 'pointer');*/ ?>
    <?php /*//	                  $(this).css('cursor', 'hand');*/ ?>
                    <?php /*},*/ ?>
                    <?php /*function () {*/ ?>
                        <?php /*$(this).removeClass('pink');*/ ?>
    <?php /*//	                  $(this).css('cursor', 'auto');*/ ?>
                    <?php /*});*/ ?>
        <?php /*});*/ ?>
    <?php /*</script>*/ ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <footer style="background-color: #26A69A" class="page-footer">
        <div class="container">
            <div class="row">
                <div class="col l6 s12">
                    <h5 class="white-text"><?php echo e(Lang::get('detail.about')); ?></h5>
                    <ul>
                        <li><a class="grey-text text-lighten-3" href="#!">Alamat Kantor</a></li>
                        <li><a class="grey-text text-lighten-3" href="#!">Indonesia</a></li>
                        <li><a class="grey-text text-lighten-3" href="#!">email@email.com</a></li>
                        <li><a class="grey-text text-lighten-3" href="#!">876543210</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <div class="container">
                © 2016 Copyright
                <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
        </div>
    </footer>
    <!--  Scripts-->
    <script type="text/javascript">
        $(document).ready(function() {
            $('select').material_select();
            $("li img.lang_id").on('click', function() {
                alert('berhasil');
            });
        });
    </script>
    <!--script-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>