<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('smbr/img/favicon.png')); ?>"/>
    <?php /*<link type="text/css" rel="stylesheet" href="<?php echo e(asset('smbr/css/login.css')); ?>"  media="screen,projection"/>*/ ?>
    <style type="text/css">
        html,
        body {
            height: 100%;
        }
        html {
            display: table;
            margin: auto;
        }
        body {
            display: table-cell;
            vertical-align: middle;
        }
        #page-wrap {
            width: 350px;
        }
        .margin {
            margin: 0 !important;
        }
    </style>
        <!--mobile-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <!--Google Icon Font-->
        <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        
        <!--css-->
        <link href="<?php echo e(asset('smbr/css/materialize.min.css')); ?>" type="text/css" rel="stylesheet"  media="screen,projection"/>
        <link href="<?php echo e(asset('smbr/css/materialize.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection"/>
        <?php /*<link href="<?php echo e(asset('smbr/css/style.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection"/>*/ ?>

        <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
        <script src="<?php echo e(asset('smbr/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('smbr/js/materialize.min.js')); ?>"></script>

    <script src="<?php echo e(asset('smbr/js/ffLg.js')); ?>"></script>
    <script src="<?php echo e(asset('smbr/js/forms.js')); ?>"></script>
    <script src="<?php echo e(asset('smbr/js/dist/jquery.validate.js')); ?>"></script>
    <script src="<?php echo e(asset('smbr/js/dist/additional-methods.js')); ?>"></script>
</head>

<body bgcolor="#0D47A1">

	<?php /*<div id="page-wrap" class="z-depth-2">*/ ?>
	<?php /*<div id="login" class="row z-depth-2">*/ ?>
        <div id="page-wrap">
            <div class="row">
                <div class="input-field col s12 center">
                    <img src="<?php echo e(asset('smbr/img/logo_small.png')); ?>" alt="" class="responsive-img valign profile-image-login">
                    <?php /*<p class="center login-form-text">W3lessons - Material Design Login Form</p>*/ ?>
                </div>
            </div>

            <div class="col s12 card-panel z-depth-2">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
	<?php /*</div>*/ ?>

</body>

</html>