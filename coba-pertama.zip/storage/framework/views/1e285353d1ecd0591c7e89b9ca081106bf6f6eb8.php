

<?php $__env->startSection('title', 'login page'); ?>

<?php $__env->startSection('content'); ?>
		<form action="<?php echo e(route('masuk')); ?>" method="post" name="login_form">
                <div class="row margin">
                    <div class="input-field col s12">
                        <i class="mdi-social-person-outline prefix"></i>
                        <input id="username" required type="text" name="username" />
                        <label for="username" >Username</label>
                    </div>
                </div>
                <div class="row margin">
                    <div class="input-field col s12">
                        <i class="mdi-action-lock-outline prefix"></i>
                        <input type="password" name="password" id="password"/>
                        <label for="password">Password</label>
                        <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                        <!--<input type="button" 
                               value="Login" 
                               onclick="formhash(this.form, this.form.password);" /> -->
                    </div>
                </div>
                <div class="clearfix">
                    
                </div>
                    <center>

                        <button class="btn valign yellow black-text" onclick="formhash(this.form, this.form.password);">Login
                        <?php /*<button class="btn valign" >Login*/ ?>
                                <i class="material-icons right">send</i>
                        </button>
                    </center>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>