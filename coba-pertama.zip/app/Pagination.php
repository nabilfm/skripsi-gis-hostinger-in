<?php
/**
 * Created by PhpStorm.
 * User: maryatimth
 * Date: 5/9/2016
 * Time: 1:27 PM
 */

namespace App;

use Landish\Pagination\Materialize;

class Pagination extends Materialize
{

}