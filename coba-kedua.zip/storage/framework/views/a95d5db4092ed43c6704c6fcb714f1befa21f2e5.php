<div class="section white" id="smp" >
    <div class="container">
        <div class="row">
            <?php $__empty_1 = true; foreach($smp as $dataFgdb): $__empty_1 = false; ?>
            <a href="" class="black-text">
                <?php /*<a href="<?php echo e(route('editFg',['id'=>$dataFgdb->id])); ?>" class="black-text">*/ ?>
                    <div class="col s12 m12 l6">
                        <div id="c_user" class="card-panel z-depth-1 hoverable">
                            <div id="cc_user">
                                <div class="card-content">
                                    <h5><?php echo e($dataFgdb->nama); ?></h5>
                                </div>
                                <div class="card-content">
                                    <span><?php echo e($dataFgdb->alamat); ?></span>
                                    <input type="hidden" name="lblfg" value="<?php echo e($dataFgdb->id); ?>">
                                    <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                                </div>
                            </div>
                            <div id="del_user">
                                <?php /*<form id="form_user" action="<?php echo e(route('deleteFg')); ?>" method="post" name="register_form">*/ ?>
                                    <form id="form_user" action="" method="post" name="register_form">
                                        <div class="card-content">
                                            <span><?php echo e($dataFgdb->npsn); ?><a id="btn_del" class="secondary-content tooltipped" data-position="bottom" data-delay="50" data-tooltip="delete this Field Guide"><i class="material-icons">deletes</i></a></span>
                                            <input type="hidden" name="lblfg" value="<?php echo e($dataFgdb->label); ?>">
                                        </div>
                                    </form>
                            </div>
                        </div>
                    </div>
                </a>
                <?php endforeach; if ($__empty_1): ?>
                <center><h3 class="red-text">No Fieldguide</h3></center>
                <?php endif; ?>
        </div>
    </div>
</div>
<div class="section white" id="sma" >
    <div class="container">
        <div class="row">
            <?php $__empty_1 = true; foreach($sma as $dataFgdb): $__empty_1 = false; ?>
            <a href="" class="black-text">
                <?php /*<a href="<?php echo e(route('editFg',['id'=>$dataFgdb->id])); ?>" class="black-text">*/ ?>
                    <div class="col s12 m12 l6">
                        <div id="c_user" class="card-panel z-depth-1 hoverable">
                            <div id="cc_user">
                                <div class="card-content">
                                    <h5><?php echo e($dataFgdb->nama); ?></h5>
                                </div>
                                <div class="card-content">
                                    <span><?php echo e($dataFgdb->alamat); ?></span>
                                </div>
                            </div>
                            <div id="del_user">
                                <?php /*<form id="form_user" action="<?php echo e(route('deleteFg')); ?>" method="post" name="register_form">*/ ?>
                                    <form id="form_user" action="" method="post" name="register_form">
                                        <div class="card-content">
                                            <span><?php echo e($dataFgdb->npsn); ?><a id="btn_del" class="secondary-content tooltipped" data-position="bottom" data-delay="50" data-tooltip="delete this Field Guide"><i class="material-icons">deletes</i></a></span>
                                            <input type="hidden" name="lblfg" value="<?php echo e($dataFgdb->label); ?>">
                                        </div>
                                    </form>
                            </div>
                        </div>
                    </div>
                </a>
                <?php endforeach; if ($__empty_1): ?>
                <center><h3 class="red-text">No Fieldguide</h3></center>
                <?php endif; ?>
        </div>
    </div>
</div>
<div class="section">
    <div class="container center">
        <?php /*<?php echo (new App\Pagination($smp))->render(); ?>*/ ?>
    </div>
</div>